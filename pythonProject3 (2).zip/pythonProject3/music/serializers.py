from rest_framework import serializers
from .models import Artist, Song, Album

class ArtistSerializer(serializers.ModelSerializer):

    class Meta:
        model = Artist
        fields = ('first_name', 'last_name', 'image', 'created')


class SongSerializer(serializers.ModelSerializer):
    artist = ArtistSerializer(read_only=True)
    class Meta:
        model = Song
        fields = ('title','music', 'artist', 'duration', 'created')


class AlbumSerializer(serializers.ModelSerializer):
    artist = ArtistSerializer(read_only=True)
    class Meta:
        model = Album
        fields = ('name', 'image', 'created', 'artist')

