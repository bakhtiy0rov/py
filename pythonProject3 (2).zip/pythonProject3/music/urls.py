from django.shortcuts import render
from .views import MainPageAPIView, ArtistAPIView, SongAPIView, AlbumAPIView, ArtistDetailAPIView, SongDetailAPIView, \
    AlbumDetailAPIView
from django.urls import path, include
from rest_framework.routers import DefaultRouter
router = DefaultRouter()
router.register(prefix="songs", viewset=SongDetailAPIView)

urlpatterns = [
    path('main/', MainPageAPIView.as_view(), name='main'),
    path('artist/', ArtistAPIView.as_view(), name='artist'),
    path('artist/<int:id>', ArtistDetailAPIView.as_view(), name='artist-detail'),
    path("", include(router.urls)),
    path('album/', AlbumAPIView.as_view(), name='album'),
    path('album/<int:id>', AlbumDetailAPIView.as_view(), name='album-detail'),

]